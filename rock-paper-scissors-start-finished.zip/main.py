import random

rock = '''
    _______
---'   ____)
      (_____)
      (_____)
      (____)
---.__(___)
'''

paper = '''
    _______
---'   ____)____
          ______)
          _______)
         _______)
---.__________)
'''

scissors = '''
    _______
---'   ____)____
          ______)
       __________)
      (____)
---.__(___)
'''

#Write your code below this line 👇
for i in range(10):
# user_input = int(input("What do you choose? Type 0 for Rock, 1 for Paper or 2 for Scissors."))
  user_input = random.randrange(3)
  choices = [rock, paper, scissors]
  com1_choice = random.randrange(3)
  
  print(f"you chose: \n {choices[user_input]} ")
  print(f"computer chose: \n {choices[com1_choice]} ")
  Win = "you Win"
  Lose = 'you lose'
  if user_input != com1_choice :
    if user_input == 0:
      if com1_choice == 1:
        print(Lose)
      else:
        print(Win)
    elif user_input == 1:
      if com1_choice == 2:
        print(Lose)
      else:
        print(Win)
    else:
      if com1_choice == 0:
        print(Lose)
      else:
        print(Win)
      
    
  else:
    print('Draw')
